from ui import *
import matplotlib
import numpy as np

b = Board() # Generate Board

if __name__ == "__main__":
    UI(b) # Start program

# TODO : change Neighbour tries label to accepted tries: X of Y (nn.nn%)
